import java.util.Random;
import java.lang.Math;

class Insertion {

  void insert(int[] array, String type) {
    //the function is getting the array fine
    int n = array.length;
    int counter = 0;
    for (int i = 1; i < array.length; i++) {
      int key = array[i];
      int j = i - 1;

      while (j >= 0 && array[j] > key) {
        array[j + 1] = array[j];
        j = j - 1;
        counter++;
      }
      array[j + 1] = key;
      
    }
    System.out.println("The amount of number switches for " + type + " array is " + counter + ". n^2/4 =" + (Math.pow(32,2)/4));
    

  }
  void increasingSizes(int[] array, String type) {
    //the function is getting the array fine


    int n = array.length;
    int counter = 0;
    for (int i = 1; i < array.length; i++) {
      int key = array[i];
      int j = i - 1;

      while (j >= 0 && array[j] > key) {
        array[j + 1] = array[j];
        j = j - 1;
        counter++;
      }
      array[j + 1] = key;
      
    }
    System.out.println("The amount of number switches for " + type + " array is " + counter + ". n^2/4 =" + (Math.pow(n,2)/4) );
    

  }

}


public class Main {
  public static void main(String[] args) {
    Random rand = new Random();
    System.out.println("Hello world!");

    int[] worst = new int[32];
    int[] best = new int[32];
    int[] random = new int[32];

    int[] increasingSize1 = new int[100];
    int[] increasingSize2 = new int[1000];
    int[] increasingSize3 = new int[10000];

    //System.out.println("Here is the worst array:");
    for (int i = 0; i < worst.length; i++) {
      worst[i] = worst.length - i;
    }
    //System.out.println("Here is the best array:");
    for (int i = 0; i < best.length; i++) {
      best[i] = i + 1;
    }
    //System.out.println("Here is the random array:");
    for (int i = 0; i < random.length; i++) {
      random[i] = rand.nextInt(32);
    }

    for (int i = 0; i < increasingSize1.length; i++) {
      increasingSize1[i] = rand.nextInt(100);
    }
    for (int i = 0; i < increasingSize2.length; i++) {
      increasingSize2[i] = rand.nextInt(1000);
    }
    for (int i = 0; i < increasingSize3.length; i++) {
      increasingSize3[i] = rand.nextInt(10000);
    }


    Insertion insert = new Insertion();
    insert.insert(worst, "worst");
    insert.insert(best, "best");
    insert.insert(random, "random");

    insert.increasingSizes(increasingSize1, "n=100");
    insert.increasingSizes(increasingSize2,"n=1000");
    insert.increasingSizes(increasingSize3,"n=10000");

    System.out.println("It does show O(n^2), since each array's switches increases times 100. The constant looks like 25.")

  }
}